package com.example.firebase_notifications

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
