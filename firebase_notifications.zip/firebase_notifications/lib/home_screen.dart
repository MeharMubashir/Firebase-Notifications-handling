import 'dart:convert';

import 'package:firebase_notifications/notifications_services.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  NotificationServices notificationServices = NotificationServices();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    notificationServices.requestNotificationPermission();
    notificationServices.firebaseInit(context);
    notificationServices.setupInteractMessage(context);
    notificationServices.getDeviceToken().then((value) {
      if (kDebugMode) {
        print('device token ');
        print(value);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.blue,
        title: const Text(
          'Home Screen',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Center(
        child: TextButton(
          onPressed: () {
            notificationServices.getDeviceToken().then((value) async {
              var data = {
                'to': value.toString(),
                'priority': 'high',
                'notification': {
                  'title': 'Mehar Mubashir',
                  'body': 'Flutter Develpor'
                },
                'data': {'type': 'message', 'id': '1234'}
              };
              await http.post(Uri.parse('https://fcm.googleapis.com/fcm/send'),
                  body: jsonEncode(data),
                  headers: {
                    'Content-Type': 'application/json;charset=UTF-8',
                    'Authorization':
                        'key=AAAAanGUWnc:APA91bEGghlSpRNKyBRYiHZrCwpRM7pRxAHgnsnllodbNBxxHkRrVhDGShoEwWBBSOs4N3nbQcYROIebZmu3BUODs4hGFbCK7PapZ-r8_gcFYLkrm53Z1myCqS0XkxDix1sAU1kwqPKJ'
                  });
            });
          },
          child: Text(
            'Send Notifications',
            style: TextStyle(color: Colors.blue),
          ),
        ),
      ),
    );
  }
}
